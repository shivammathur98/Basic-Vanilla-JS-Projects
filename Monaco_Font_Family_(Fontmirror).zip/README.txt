To learn more about the font family and its license, visit https://www.fontmirror.com/monaco

License: Free for personal use.